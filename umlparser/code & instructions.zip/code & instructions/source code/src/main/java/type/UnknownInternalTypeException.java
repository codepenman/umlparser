package type;

/**
 * Harish Kumar K V
 */
public class UnknownInternalTypeException extends Exception {
    public UnknownInternalTypeException () {
        super();
    }
}
