/**
 * Harish Kumar K V
 */
public enum Action {
    OBJECT_INITIALIZATION,
    PARAMETER,
    IMPLEMENTATION,
    EXTENSION,
    DECLARATION,
    INITIALIZATION,
    RETURN
}
