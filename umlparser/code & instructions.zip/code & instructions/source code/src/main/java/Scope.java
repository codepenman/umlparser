/**
 * Harish Kumar K V
 */
public enum Scope {
    CLASS,
    CONSTRUCTOR,
    METHOD,
    FIELD,

}
